@php
    function ddtest($data)
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        die();
    }
@endphp

